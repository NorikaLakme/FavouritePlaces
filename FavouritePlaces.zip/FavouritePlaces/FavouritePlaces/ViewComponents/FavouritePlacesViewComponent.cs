﻿using FavouritePlaces.DLL;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FavouritePlaces.ViewComponents
{
    public class FavouritePlacesViewComponent : ViewComponent
    {
        private readonly IFavouritePlaces favouritePlaces;

        public FavouritePlacesViewComponent(IFavouritePlaces favouritePlaces)
        {
            this.favouritePlaces = favouritePlaces;
        }

        public IViewComponentResult Invoke()
        {
            var count = favouritePlaces.GetCount();
            return View(count);
        }
    }
}
