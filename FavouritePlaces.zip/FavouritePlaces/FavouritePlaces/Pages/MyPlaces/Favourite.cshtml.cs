using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FavouritePlaces.BLL;
using FavouritePlaces.DLL;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Configuration;

namespace FavouritePlaces.Pages.MyPlaces
{ 
    public class FavouriteModel : PageModel
    {
        private readonly IConfiguration config;
        private readonly IFavouritePlaces favouritePlaces;
        public string SearchTerm;


        public string Message { get; set; }
        public IEnumerable<Place> Places { get; set; }

        public FavouriteModel(IConfiguration config, IFavouritePlaces favouritePlaces)
        {
            this.config = config;
            this.favouritePlaces = favouritePlaces;
        }
        public void OnGet(string searchTerm)
        {
            SearchTerm = searchTerm;
            Message = config["Message"];
            Places = favouritePlaces.GetAllByName(searchTerm);
        }
    }
}
