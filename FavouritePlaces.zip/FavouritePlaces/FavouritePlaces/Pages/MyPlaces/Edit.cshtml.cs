using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FavouritePlaces.BLL;
using FavouritePlaces.DLL;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace FavouritePlaces.Pages.MyPlaces
{
    public class EditModel : PageModel
    {
        private readonly IFavouritePlaces favouritePlaces;
        private readonly IHtmlHelper htmlHelper;

        [BindProperty]
        public Place Place { get; set; }
       
        public IEnumerable<SelectListItem> Cities { get; set; }
        public EditModel(IFavouritePlaces favouritePlaces, IHtmlHelper htmlHelper)
        {
            this.favouritePlaces = favouritePlaces;
            this.htmlHelper = htmlHelper;
        }
        public IActionResult OnGet(int? placeId)
        {
            Cities = htmlHelper.GetEnumSelectList<Contry>();
          if(placeId.HasValue)
            {
                Place = favouritePlaces.GetId(placeId.Value);
            }
            else
            {
                Place = new Place();
            }
            if(Place == null){
                return RedirectToPage("./NotHere");
            }return Page();
        }

        public IActionResult OnPost()
        {
            if(!ModelState.IsValid)
            {
                Cities = htmlHelper.GetEnumSelectList<Contry>();
                return Page();
                
            }if(Place.Id > 0)
            {
                TempData["Message"] = "Your place is updated";
                Place = favouritePlaces.UpDate(Place);
               
            }
            else
            {
                TempData["Message"] = "Your new place is saved";
                favouritePlaces.Add(Place);
                
            }
            favouritePlaces.Commit();
         
            return RedirectToPage("./Details", new { placeId = Place.Id});
            
            
        }
    }
}
