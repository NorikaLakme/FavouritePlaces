using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FavouritePlaces.BLL;
using FavouritePlaces.DLL;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace FavouritePlaces.Pages.MyPlaces
{
    public class CreateModel : PageModel
    {
        private readonly IFavouritePlaces favouritePlaces;
        private readonly IHtmlHelper htmlHelper;
        public IEnumerable<SelectListItem> Cities;

        [BindProperty]
        public Place Place { get; set; }

        public CreateModel(IFavouritePlaces favouritePlaces, IHtmlHelper htmlHelper)
        {
            this.favouritePlaces = favouritePlaces;
            this.htmlHelper = htmlHelper;
        }
        public IActionResult OnGet()
        {
            //Place = new Place();
            Cities = htmlHelper.GetEnumSelectList<Contry>();
            return Page();

        }
        public IActionResult OnPost()
        {
            if(ModelState.IsValid)
            {
                TempData["Message"] = "New created";
                favouritePlaces.Add(Place);
                favouritePlaces.Commit();
                return RedirectToPage("./Favourite");
            }
            Cities = htmlHelper.GetEnumSelectList<Contry>();
            return Page();
           
        }
    }
}
