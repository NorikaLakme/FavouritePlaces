using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FavouritePlaces.BLL;
using FavouritePlaces.DLL;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace FavouritePlaces.Pages.MyPlaces
{
    public class DeleteModel : PageModel
    {
        private readonly IFavouritePlaces favouritePlaces;
        [BindProperty]
        public Place Place { get; set; }
        public DeleteModel(IFavouritePlaces favouritePlaces)
        {
            this.favouritePlaces = favouritePlaces;
        }
        public IActionResult OnGet(int placeId)
        {
            Place = favouritePlaces.GetId(placeId);
            if(Place == null)
            {
                return RedirectToPage("./NotFound");
            }
            return Page();
        }

        public IActionResult OnPost(int placeId)
        {
            var place = favouritePlaces.Deletedata(placeId);
            favouritePlaces.Commit();
            if(place == null)
            {
                return RedirectToPage("./NotFound");
            }
            TempData["Message"] = $"{place.Name} is deleted.";
            return RedirectToPage("./Favourite");
        }
    }
}
