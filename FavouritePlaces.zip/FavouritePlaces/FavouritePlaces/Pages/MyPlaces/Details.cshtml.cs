using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FavouritePlaces.BLL;
using FavouritePlaces.DLL;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace FavouritePlaces.Pages.MyPlaces
{
    public class DetailsModel : PageModel
    {
        private readonly IFavouritePlaces favouritePlaces;
        [TempData]
        public string Message { get; set; }
        public DetailsModel(IFavouritePlaces favouritePlaces)
        {
            this.favouritePlaces = favouritePlaces;
        }
        public Place Place { get; set; }
        public IActionResult OnGet(int placeId)
        {
            Place = favouritePlaces.GetId(placeId);
            if(Place == null)
            {
                return RedirectToPage("./NotHere");
            }
            return Page();
        }
    }
}
