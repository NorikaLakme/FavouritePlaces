﻿namespace FavouritePlaces.BLL
{
    public enum Contry
    {
        Italy,
        France,
        UK,
        Spain
    }
}
