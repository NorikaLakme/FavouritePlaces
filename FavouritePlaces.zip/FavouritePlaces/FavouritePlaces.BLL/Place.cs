﻿using System.ComponentModel.DataAnnotations;

namespace FavouritePlaces.BLL
{
    public class Place
    {
        
        public int Id { get; set; }

        [Required, StringLength(80)]
        public string Name { get; set; }

        [Required, StringLength(250)]
        public string Location { get; set; }
        public Contry City { get; set; }
    }
}
