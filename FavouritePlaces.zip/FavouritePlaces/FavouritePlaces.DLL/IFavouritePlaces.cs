﻿using FavouritePlaces.BLL;
using System.Collections.Generic;

namespace FavouritePlaces.DLL
{
    public interface IFavouritePlaces
    {
        IEnumerable<Place> GetAllByName(string name);
        Place GetId(int id);
        Place UpDate(Place updatedPlace);
        int Commit();
        Place Add(Place addNew);
        Place Deletedata(int id);
        int GetCount();
    }
}
