﻿using FavouritePlaces.BLL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FavouritePlaces.DLL
{
    public class SqlFavouritePlacesData : IFavouritePlaces
    {
        private readonly FavouritePlacesDbContext favouritePlacesDbContext;

        public SqlFavouritePlacesData(FavouritePlacesDbContext favouritePlacesDbContext )
        {
            this.favouritePlacesDbContext = favouritePlacesDbContext;
        }
        public Place Add(Place addNew)
        {
            favouritePlacesDbContext.Add(addNew);
            return addNew;
            
        }

        public int Commit()
        {
            return favouritePlacesDbContext.SaveChanges();
        }

        public Place Deletedata(int id)
        {
            var newPlace = GetId(id);
            if(newPlace != null)
            {
                favouritePlacesDbContext.Remove(newPlace);

            }return newPlace;

        }

        public IEnumerable<Place> GetAllByName(string name)
        {
            //return favouritePlacesDbContext.Places.Where((r) => string.Equals(r.Name, name, StringComparison.OrdinalIgnoreCase));
            var query = from r in favouritePlacesDbContext.Places
                        where r.Name.StartsWith(name) || string.IsNullOrEmpty(name)
                        orderby r.Name
                        select r;
            return query;
        }

        public int GetCount()
        {
            return favouritePlacesDbContext.Places.Count();
        }

        public Place GetId(int id)
        {
            return favouritePlacesDbContext.Places.Find(id);
        }

        public Place UpDate(Place updatedPlace)
        {
            var entity = favouritePlacesDbContext.Places.Attach(updatedPlace);
            entity.State = Microsoft.EntityFrameworkCore.EntityState.Modified;
            return updatedPlace;
        }
    }
    //public int GetCount()
    //    {
    //        return favouritePlacesDbContext.Places.Count();
    //    }

    //    public Place GetId(int id)
    //    {
    //        return favouritePlacesDbContext.Places.Find(id);
    //    }

    //    public Place UpDate(Place updatedPlace)
    //    {
    //        var entity = favouritePlacesDbContext.Places.Attach(updatedPlace);
    //        entity.State = Microsoft.EntityFrameworkCore.EntityState.Modified;
    //        return updatedPlace;


    //    }
    }


