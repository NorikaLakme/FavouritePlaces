﻿using FavouritePlaces.BLL;
using System;
using System.Collections.Generic;
using System.Linq;

namespace FavouritePlaces.DLL
{
    public class InMemoryFavouritePlaces : IFavouritePlaces
    {
        List<Place> places;
        public InMemoryFavouritePlaces()
        {
            places = new List<Place>()
            {
            new Place { Id = 1, City = Contry.France, Location = "Paris", Name = "IffelTower" },
            new Place { Id = 2, Name = "Picaso", City = Contry.Italy, Location = "Milan" },
            new Place { Id = 3, Name = "Olympics", City = Contry.Spain, Location = "Madrid" },
             };

        }

        public Place GetId(int id)
        {
            return places.SingleOrDefault(p => p.Id == id);
        }
  
        public IEnumerable<Place> GetAllByName(string name = null)
        {
            return from r in places
            where string.IsNullOrEmpty(name) || r.Name.StartsWith(name)
            orderby r.Name
            select r;

            //return from r in places
            //       let newUpper = r.Name.ToUpper()
            //       let newLower = r.Name.ToLower()
            //       where string.IsNullOrEmpty(name) || r.Name.Equals(name, StringComparison.OrdinalIgnoreCase)
            //       orderby r.Name
            //       select r;


            }

        public Place UpDate(Place updatedPlace)
        {
            var newPlace = places.SingleOrDefault(p => p.Id == updatedPlace.Id);
            if(newPlace != null)
            {
                newPlace.Name = updatedPlace.Name;
                newPlace.Location = updatedPlace.Location;
                newPlace.City = updatedPlace.City;

            }return newPlace;
        }

        public int Commit()
        {
            return 0;
        }

        public Place Add(Place addNew)
        {
             places.Add(addNew);
            addNew.Id = places.Max(p => p.Id) + 1;
            return addNew;
        }

        public Place Deletedata(int id)
        {
            var newPlace = GetId(id);
            if(newPlace != null)
            {
                places.Remove(newPlace);
            }
            return newPlace;
        }

        public int GetCount()
        {
            return places.Count();
        }
    }
    }

