﻿using FavouritePlaces.BLL;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace FavouritePlaces.DLL
{
   public class FavouritePlacesDbContext : DbContext
    {
        public FavouritePlacesDbContext(DbContextOptions<FavouritePlacesDbContext> options)
        : base(options)
        {

        }
        public DbSet<Place> Places { get; set; }
    
    }
}
